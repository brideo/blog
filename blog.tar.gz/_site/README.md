#Nathan McBride's Blog

Powered by <a href="http://github.com/rosario/kasper">Kasper theme</a>.

Feel free to submit a pull request if you would like to edit a post or create a new one.

This blog is built on <a href="http://jekyllrb.com/">Jekyll</a>. The posts can be found in the `_posts` directory.

View <a href="http://brideo.co.uk/">my blog</a>.
